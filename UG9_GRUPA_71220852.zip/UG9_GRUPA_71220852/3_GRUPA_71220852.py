a=int(input("Masukkan Panjang:"))
b=int(input("Masukan lebar:"))
c=int(input("Masukan Jari Jari:"))

d=a*b
e=1/2*22/7*c*c
f=d+e
g=f/15
print("Area tersebut membutuhkan",round(g),"kaleng cat")
      
