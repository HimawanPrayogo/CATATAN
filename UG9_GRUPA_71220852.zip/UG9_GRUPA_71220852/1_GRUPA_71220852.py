a=input("Masukan nama Anda:")
b=input("Masukan nama matakuliah:")
c=input("Masukan grup Anda:")
if a== "Cassandra":
    print("""Haloo! CassandraCassandra
          Anda tergabung dalam kelas Praktikum Teknologi Komputer Pada Grup A""")

elif a== "Alaska":
        print("""Halooo! AlaskaAlaska
              Anda Tergabung Pada Kelas Logika Matematika Pada Grup C""")
else:
    print("eror")
    
