a=int(input("Suhu dalam skala Fahrenheit:"))
b=(a-32)*5/9
print(a,"derajat Fahrenheit dikonversi menjadi",round(b),"derajat celcius")
